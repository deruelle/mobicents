This folder and its subfolders contain a copy of the JSLEE 1.0 Test Compatibility Kit.
It is used on a on continuous basis to ensure that Mobicents remains JSLEE compliant at all times.
